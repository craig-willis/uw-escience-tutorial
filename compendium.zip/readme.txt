
"run_all_scripts.R"    batch file to recreate all tables and figures                                             
"bbindex.csv" %% Broadband Data Used Throughout
"codebooks.html.pdf" %% Codebook
"CopyOfanes_timeseries_2012.sav" %% ANES Data used for Fig 4, Table E2, Table E3                                 
"CopyOfNov 2004 Post-Election_csv.csv" %% Pew Data Used in Appendix E  
"demographics2004.csv" %% comscore data 2004 Fig C1
"demographics2008.csv"   %% comscore data 2008 Fig C1                                           
 "education.csv"  %% Education data for ROW Validation check                                                   
 "FigA1.R"   %% Fig A1 Code                                                         
"figc1.R"  %% Fig c1 Code                                                           
"Figure_1_map.R"     %% Fig 1 Code                                                
"Figure_2_providerssubscribers.R"  %% Fig 2 Code                                  
"Figure_3_comscoreproviders.R"   %% Fig 3 Code                                                                     
"Figure_4_nes.R"   %% Fig 4 Code                                                                                                                      
"gentzkow.RData"   %% Data used for Fig 3                                                  
"hstracts.csv"   %% Data used for Fig C1                                                                                                     
"medianincomebystate.csv"    %% ROW Validation check income data                                       
"mergedcounty.RData"      %% County-level main dataset                                                                                 
"mergeddataset.RData"    %% Individual-level main dataset                                                                                                                            
"naes200aff.RData"        %% ROW Validation check income data                                                                                 
"Partisan_Balance_For_Use2011_06_09b.csv"                           
"providers_ziplevel2004.csv"     %% Data used for Fig C1                                                                                                                                        
"providers_ziplevel2008.csv"       %% Data used for Fig C1                                                                                                                                      
"readme.txt"                                                        
"ROW Validation Checks.R"    %% Robustness check data                                       
"shor mccarty 1993-2013 state aggregate data public July 2014.RData" "    %% Robustness check data
"T_S_ideologystate.csv"      %% Robustness check data                                         
"Table1.R"             %% Table 1 code                                             
"Table2.R"             %% Table 2 code                                             
"tablec1.R"                               %% Table c1 code                          
"TableD1D2D3.R"                      %% Table D1,D2,D3 code                               
"tablese3e4.R"                             %% Tables in appendix E                         